const express = require('express')
const User = require('./../models/user')
const crypto = require('crypto')
const router = express.Router()

// Create New Article
router.get('/', async (req, res) => {
    res.render('user/login', { user: new User() })
})


router.post('/', async (req, res) => {    
    try {
    let user = await User.findOne({username: (req.body.user)})
    let msg;
    if (!user) {
        msg = "Invalid Username"
        res.render('user/login', {msg: msg})
    } else {
        let auth = await User.findOne({username: (req.body.user), password: (req.body.password)})
        if (auth) {

            res.cookie("auth", 1, {maxAge: 900000, httpOnly: true})
            res.render('articles/index', {authenticated: true})
        } else {
            msg = "Invalid Password"
            res.render('user/login', {msg: msg})
        }
    }
}catch(error){console.log(error)
}
})

module.exports = router
