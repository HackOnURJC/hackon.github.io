const express = require('express')
const mongoose = require('mongoose')
const loginRouter = require('./routes/login')
const methodOverride = require('method-override')
const cookieParser = require('cookie-parser');
const getEnv = require('getenv')
const User = require("./models/user");
const app = express()
let DB_HOST = getEnv('DB_HOST', 'localhost')
mongoose.connect(`mongodb://${DB_HOST}/blog`)

app.set('view engine', 'ejs')
app.use(express.urlencoded({ extended: false }))
app.use(methodOverride('_method'))
app.use(express.json());
app.use(cookieParser('HackOn2022CTFConference'));

function authenticated(c) {
    if (typeof c == 'undefined')
        return false
    //console.log(c)
    return c === 1;
}


app.get('/', async (req, res) => {
    res.render("articles/index", {
        authenticated: authenticated(req.cookies.user)
    })
})

app.use('/login', loginRouter)

// Crear el usuario con la flag
let user = new User()
user.username = 'admin'
user.password = 'L0H4Sc0ns3Gu1d0'
console.log("user: " + user.username + " password: " + user.password)
u = user.save()

app.listen(5001)
