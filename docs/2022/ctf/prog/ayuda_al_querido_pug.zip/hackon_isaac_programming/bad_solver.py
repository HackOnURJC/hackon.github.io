import socket

class Netcat:
    """ Python 'netcat like' module """
    def __init__(self, ip, port):
        self.buff = ""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect((ip, port))

    def read(self, length=1024):
        """ Read 1024 bytes off the socket """
        data = self.socket.recv(length).decode('utf-8').strip()
        return data

    def write(self, data):
        data = data + "\n"
        self.socket.send(data.encode("ascii"))

    def close(self):
        self.socket.close()

# start a new Netcat() instance
nc = Netcat('127.0.0.1', 9994)

# get to the prompt
print(nc.read())

iters = 0
flag = ""
while True:
    respuesta = ""
    for i in ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0','{','}','_']:
        iters += 1
        curFlag = flag+str(i)
        nc.write(curFlag)
        respuesta = nc.read()
        while not (("Mas "+curFlag in respuesta) or ("Menos "+curFlag in respuesta) or ("Caracter" in respuesta) or ("Premio" in respuesta)):
            respuesta = nc.read()
        if "Caracter" in respuesta:
            flag=flag+str(i)
            print(flag)
            break
        if "Premio" in respuesta:
            flag = flag + str(i)
            print("Flag -> " + flag)
            break
    if "Premio" in respuesta:
        break
print(iters)
nc.close()
