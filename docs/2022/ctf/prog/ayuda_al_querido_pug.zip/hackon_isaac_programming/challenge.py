import os
import time

def main():
    flag = "hackon{b1n4ry_s34rch_1s_v3ry_p0werfull_t3chn1qu3_t0_s0lv3_l4rge_1nst4nc3s_pr0bl3ms}"

    print("Cual sera la contrasena...\nYo solo te voy a decir como de cerca estas, para eso te responderé menos o mas para el último caracter.\nPista: la contrasena empieza por h...")
    opcion = input()
    while opcion!=flag:
        opcion = opcion.strip()
        flag = flag.strip()
        if(len(opcion)>len(flag)):
            print("La flag es un poquito más corta")
        elif ord(flag[len(opcion)-1])==ord(opcion[len(opcion)-1]):
            print("Caracter " + str(len(opcion)) + " correcto")
        elif ord(flag[len(opcion)-1])<ord(opcion[len(opcion)-1]):
            print("Menos " + opcion)
        elif opcion == flag:
            return
        else:
            print("Mas " + opcion)
        time.sleep(30)
        opcion = input()
    if opcion == flag:
        print("Premio la flag es -> " + flag)

main()
