package main

import (
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/dixonwille/wmenu/v5"
)

type flor struct {
	Nombre string
	Precio int16
}

var saldo = int16(100)

func main() {
	fmt.Println(`
	 ▄▄▄▄▄▄▄ ▄▄▄     ▄▄▄▄▄▄▄ ▄▄▄▄▄▄   ▄▄▄ ▄▄▄▄▄▄▄ ▄▄▄▄▄▄▄ ▄▄▄▄▄▄▄ ▄▄▄▄▄▄   ▄▄▄ ▄▄▄▄▄▄
	█       █   █   █       █   ▄  █ █   █       █       █       █   ▄  █ █   █      █
	█    ▄▄▄█   █   █   ▄   █  █ █ █ █   █  ▄▄▄▄▄█▄     ▄█    ▄▄▄█  █ █ █ █   █  ▄   █
	█   █▄▄▄█   █   █  █ █  █   █▄▄█▄█   █ █▄▄▄▄▄  █   █ █   █▄▄▄█   █▄▄█▄█   █ █▄█  █
	█    ▄▄▄█   █▄▄▄█  █▄█  █    ▄▄  █   █▄▄▄▄▄  █ █   █ █    ▄▄▄█    ▄▄  █   █      █
	█   █   █       █       █   █  █ █   █▄▄▄▄▄█ █ █   █ █   █▄▄▄█   █  █ █   █  ▄   █
	█▄▄▄█   █▄▄▄▄▄▄▄█▄▄▄▄▄▄▄█▄▄▄█  █▄█▄▄▄█▄▄▄▄▄▄▄█ █▄▄▄█ █▄▄▄▄▄▄▄█▄▄▄█  █▄█▄▄▄█▄█ █▄▄█
	`)

	menu := wmenu.NewMenu("¿Qué deseas hacer?")
	menu.Option("Mirar la cartera", nil, false, mirar)
	menu.Option("Ir a trabajar", nil, false, trabajar)
	menu.Option("Comprar flag (10000€)", nil, false, flag)
	menu.Option("Comprar cactus (24€)", flor{Nombre: "cactus", Precio: int16(24)}, false, comprar)
	menu.Option("Comprar nassau (56€)", flor{Nombre: "nassau", Precio: int16(56)}, false, comprar)
	menu.Option("Comprar orquídea (44€)", flor{Nombre: "orquídea", Precio: int16(44)}, false, comprar)
	menu.Option("Comprar merlot (75€)", flor{Nombre: "merlot", Precio: int16(75)}, false, comprar)
	menu.Option("Comprar ficus (82€)", flor{Nombre: "ficus", Precio: int16(82)}, false, comprar)
	menu.Option("Salir", nil, false, func(opt wmenu.Opt) error {
		os.Exit(0)
		return nil
	})
	for {
		fmt.Println("-------------------------")
		err := menu.Run()
		if err != nil {
			if strings.Contains(err.Error(), "invalid response") {
				fmt.Println("Respuesta inválida")
			} else {
				fmt.Println("Ha ocurrido un error que no debería ocurrir")
			}
		}
	}
}

func trabajar(opt wmenu.Opt) error {
	fmt.Println("\nA trabajar otra vez ...")
	time.Sleep(15 * time.Second)
	fmt.Printf("\nHas trabajado como un verdadero campeón, toma 3€\n")
	saldo = int16(math.Abs(float64(saldo)) + 3)
	fmt.Printf("Tu saldo actual es de %d€ para gastar en flores\n\n", saldo)
	return nil
}

func mirar(opt wmenu.Opt) error {
	fmt.Printf("\nTu saldo actual es de %d€\n\n", saldo)
	return nil
}

func flag(opt wmenu.Opt) error {
	if saldo < 10000 {
		fmt.Println("No puedes quedarte sin dinero por que tienes que comprar el pan")
	} else {
		fmt.Println("HackOn{Fake_Flag_4_Testing}")
		os.Exit(1)
	}
	return nil
}

func comprar(opt wmenu.Opt) error {
	var input string
	fmt.Printf("\n¿Cuantas %s quieres?\n", opt.Value.(flor).Nombre)
	fmt.Scanf("%s", &input)
	if len(input) < 1 {
		fmt.Printf("Indtroduce algo ¿no?\n\n")
		return nil
	}
	if input[0] == '-' {
		fmt.Printf("No puedes introducir un número negativo\n\n")
		return nil
	}
	i, err := strconv.Atoi(input)
	if err != nil {
		fmt.Printf("Algo ha pasado al convertir el input a entero\n\n")
		return nil
	}
	if i == 0 {
		fmt.Printf("Hmmm ¿No quieres?\n\n")
		return nil
	}
	if i > 400 {
		fmt.Printf("No tenemos tanto stock, lo sentimos\n\n")
		return nil
	}
	total := int16(i) * opt.Value.(flor).Precio
	if saldo < total {
		fmt.Printf("No puedes quedarte sin dinero por que tienes que comprar el pan\n\n")
	} else {
		saldo = saldo - int16(total)
		if i > 1 {
			fmt.Printf("Que bonitos son los %d %s que has comprado\n", i, opt.Value.(flor).Nombre)
		} else {
			fmt.Printf("Vaya %s más precioso has comprado\n", opt.Value.(flor).Nombre)
		}
		fmt.Printf("Te ha costado %d€\n", total)
		fmt.Printf("Tu saldo actual es de %d€\n\n", saldo)
	}
	return nil
}
