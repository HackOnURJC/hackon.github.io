#!/bin/sh

/etc/init.d/xinetd start;
sleep infinity;
