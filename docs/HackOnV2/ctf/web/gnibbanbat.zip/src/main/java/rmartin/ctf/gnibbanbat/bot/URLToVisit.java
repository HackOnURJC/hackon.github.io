package rmartin.ctf.gnibbanbat.bot;

public class URLToVisit {
    public final String url;
    public final String userIP;

    public URLToVisit(String url, String userIP) {
        this.url = url;
        this.userIP = userIP;
    }
}
