package rmartin.ctf.petshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetShopApp {
    public static void main(String[] args) {
        SpringApplication.run(PetShopApp.class, args);
    }
}
