package rmartin.ctf.petshop.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.servlet.ModelAndView;
import rmartin.ctf.petshop.service.state.StateManager;
import rmartin.ctf.petshop.types.Pet;

import javax.servlet.http.HttpServletRequest;

@Controller
public class PetController {

    private static final Logger log = LoggerFactory.getLogger(PetController.class);
    private final StateManager stateManager;

    public PetController(StateManager stateManager) {
        this.stateManager = stateManager;
    }

    @GetMapping("/pets")
    public ModelAndView getAnimals(HttpServletRequest request){
        String ip = request.getRemoteAddr();
        log.info("User {} called PetController::getAnimals()", ip);

        var mv = new ModelAndView();
        mv.setViewName("pets");
        mv.addObject("pets", stateManager.getState(ip).getAnimals());
        return mv;
    }

    @PostMapping("/pets")
    public ResponseEntity<?> createPet(@RequestBody Pet pet, HttpServletRequest request){
        String ip = request.getRemoteAddr();
        log.info("User {} called PetController::createPet()", ip);

        stateManager.addPet(ip, pet);
        return ResponseEntity.ok().build();
    }
}
