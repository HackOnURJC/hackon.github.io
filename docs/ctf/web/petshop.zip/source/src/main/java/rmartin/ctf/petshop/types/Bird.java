package rmartin.ctf.petshop.types;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Bird extends Pet {

    @JsonCreator
    public Bird(@JsonProperty String name, @JsonProperty String imageURL) {
        super(name, imageURL);
    }

    @Override
    public String getMessage() {
        return "Chirp chirp";
    }
}
