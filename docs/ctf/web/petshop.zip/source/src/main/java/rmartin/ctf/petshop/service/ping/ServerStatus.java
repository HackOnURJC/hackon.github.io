package rmartin.ctf.petshop.service.ping;

import org.springframework.stereotype.Service;

@Service
public class ServerStatus {
    public String doPing(String target){
        String[] args = new String[]{"ping", "-c", "4", target};
        var command = new Command(args);
        return command.getMessage();
    }

    public String usageStats(){
        String[] args = new String[]{"free", "-h"};
        var command = new Command(args);
        return command.getMessage();
    }

}
