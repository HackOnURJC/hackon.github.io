package rmartin.ctf.petshop.service.ping;

import rmartin.ctf.petshop.types.Pet;

import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Command extends Pet {

    private String[] command;

    protected Command(){
        super("Command", "img/default.png");
    }

    public Command(String[] command) {
        super(Arrays.toString(command), "img/default.png");
        this.command = command;
    }

    @Override
    public String getMessage() {
        try {
            return doCommand();
        } catch (Exception e){
            return "Error: " + e.getMessage();
        }
    }

    protected String doCommand() throws IOException {
        var process = Runtime.getRuntime().exec(command);
        return getCommandOutput(process);
    }

    protected String getCommandOutput(Process process){
        var normal = new Scanner(process.getInputStream()).useDelimiter("\\A");
        var error = new Scanner(process.getErrorStream()).useDelimiter("\\A");

        String result = normal.hasNext()? normal.next(): "";
        result += "\n";

        result += error.hasNext()? error.next(): "";
        result += "\n";

        return result;
    }

    public void setCommand(String command){
        StringTokenizer st = new StringTokenizer(command);
        this.command = new String[st.countTokens()];
        for (int i = 0; st.hasMoreTokens(); i++){
            this.command[i] = st.nextToken();
        }
    }
}
