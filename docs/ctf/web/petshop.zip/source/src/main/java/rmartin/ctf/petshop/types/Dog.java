package rmartin.ctf.petshop.types;

import com.fasterxml.jackson.annotation.JsonCreator;

public class Dog extends Pet {

    @JsonCreator
    public Dog(String name, String imageURL) {
        super(name, imageURL);
    }

    @Override
    public String getMessage() {
        return "Guau guau";
    }
}
