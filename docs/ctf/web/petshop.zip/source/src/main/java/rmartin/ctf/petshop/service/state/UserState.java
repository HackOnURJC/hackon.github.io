package rmartin.ctf.petshop.service.state;

import rmartin.ctf.petshop.types.Pet;
import rmartin.ctf.petshop.types.Bird;
import rmartin.ctf.petshop.types.Cat;
import rmartin.ctf.petshop.types.Dog;

import java.util.*;

/**
 * Stores information for each user currently attempting to solve the challenge.
 * Each IP address creates a new profile to avoid interactions between different CTF users.
 */
public class UserState {
    private String userIP;
    private Map<Integer, Pet> animals;

    public UserState(String userIP, Map<Integer, Pet> animals) {
        this.userIP = userIP;
        this.animals = animals;
    }

    public UserState(String userIP) {
        this(userIP, getDefaultPets());
    }

    private static Map<Integer, Pet> getDefaultPets() {
        var defaultAnimals = new LinkedHashMap<Integer, Pet>();

        var exampleDog1 = new Dog("Rufus", "img/pet/dog1.jpg");
        var exampleCat1 = new Cat("Milo", "img/pet/cat1.jpg");
        var exampleBird = new Bird("Charlie", "img/pet/bird1.jpg");
        var exampleDog2 = new Dog("Tito", "img/pet/dog2.jpg");
        var exampleCat2 = new Cat("Luna", "img/pet/cat2.jpg");


        defaultAnimals.put(exampleDog1.getId(), exampleDog1);
        defaultAnimals.put(exampleCat1.getId(), exampleCat1);
        defaultAnimals.put(exampleBird.getId(), exampleBird);
        defaultAnimals.put(exampleDog2.getId(), exampleDog2);
        defaultAnimals.put(exampleCat2.getId(), exampleCat2);

        return defaultAnimals;
    }


    public String getUserIP() {
        return userIP;
    }

    public Iterable<Pet> getAnimals() {
        return animals.values();
    }

    public void deleteAnimalById(int id){
        this.animals.remove(id);
    }

    public void addAnimal(Pet pet){
        int id = pet.getId();
        this.animals.put(id, pet);
    }
}

