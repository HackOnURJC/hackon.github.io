package rmartin.ctf.petshop.service.state;

import org.springframework.stereotype.Service;
import rmartin.ctf.petshop.types.Pet;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stores information for each user currently attempting to solve the challenge.
 * Each IP address creates a new profile to avoid interactions between different CTF users.
 */
@Service
public class StateManager {
    private final Map<String, UserState> states = new ConcurrentHashMap<>();

    public UserState getState(String ip) {
        states.computeIfAbsent(ip, UserState::new);
        return states.get(ip);
    }

    public UserState setPets(String ip, Map<Integer, Pet> pets) {
        var updatedProfile = new UserState(ip, pets);
        states.put(ip, updatedProfile);
        return updatedProfile;
    }

    public UserState addPet(String ip, Pet pet) {
        var currentState = this.getState(ip);
        currentState.addAnimal(pet);
        return currentState;
    }

}
