package rmartin.ctf.petshop.types;

import com.fasterxml.jackson.annotation.JsonCreator;

public class Cat extends Pet {

    @JsonCreator
    public Cat(String name, String imageURL) {
        super(name, imageURL);
    }

    @Override
    public String getMessage() {
        return "Miauuu Miauu";
    }
}
