package rmartin.ctf.petshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaDeserializationApplicationTests {

    @Test
    void contextLoads() {
    }

}
