package rmartin.ctf.guesser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuesserApplication {

    public static void main(String[] args) {
        SpringApplication.run(GuesserApplication.class, args);
    }

}
