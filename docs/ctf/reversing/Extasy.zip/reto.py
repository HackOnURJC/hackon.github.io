#!/usr/bin/python3
import argparse, random, os
import pyaes, rsa, hashlib
from pwn import *
GROUP = 'ExtasyyElite'
DATE = '08/01/1986'

def get_args():
    parser = argparse.ArgumentParser(description='BestCipher v1.1')
    parser.add_argument('-f','--file', type=str, help='File to encrypt in current directory', required=True)
    parser.add_argument('-k','--key', type=str, help='Key Password', required=True)
    parser.add_argument('-x','--xor', type=int, help='XOR length parameter', required=True)
    args = parser.parse_args()
    return (args.file, args.key, args.xor)

def get_size(file):
    return os.stat(file).st_size


def get_data(file):
    with open(file,'rb') as fp:
        data = fp.read()
    return data


def create_identifier(size, key_pass):
    random.seed(key_pass)
    r = random.getrandbits(14)
    identifier = '{}|{}|{}|{}'.format(GROUP, DATE, str(size), str(r))
    print(identifier)
    result = hashlib.sha256(identifier.encode())
    hash = result.hexdigest()
    return (hash, r)


def get_random_aes_key(size, length=32):
    random.seed(GROUP)
    for i in range(size):
        random.getrandbits(8)
    else:
        key = bytearray((random.getrandbits(8) for x in range(length)))
        return key


def aes_encrypt(identifier, size, n, data, key):
    aes = pyaes.AESModeOfOperationCTR(key)
    encdata = aes.encrypt(data)
    write_file(identifier, size, n, encdata)


def write_file(identifier, size, n, encdata):
    hexdata = binascii.hexlify(encdata)
    toXOR = '{}->{}-{}->{}'.format(identifier, GROUP, DATE, hexdata)
    final = xor_encode(n, toXOR)
    write('CipherFile.enc',final)


def xor_encode(n, data):
    key="PacmanAularioTres"
    cipherHex=""
    for i in range(0, len(data)):
        j = i % n
        xor = ord(data[i]) ^ ord(key[j])
        cipherHex = cipherHex + hexa(xor) + " "
    return cipherHex


def hexa(num):
    h = hex(num).lstrip("0x").upper()
    h = "0" *(2-len(h)) + h
    return h


if __name__ == '__main__':
    file, key_pass, n = get_args()
    size = get_size(file)
    data = get_data(file)
    identifier, r = create_identifier(size, key_pass)
    aeskey = get_random_aes_key(size + r)
    aes_encrypt(identifier, size, n, data, aeskey)
